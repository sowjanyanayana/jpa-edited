package com.cg.xyzbank.dao;

import com.cg.xyzbank.bean.BankBean;

public interface IBankDAO {

	boolean addCustomer(BankBean bankBean);

	boolean deposit(BankBean bankBean, double depositAmount);

	boolean withDraw(BankBean bankBean, double withDrawAmount);

	boolean fundTransfer(double transferAmount, BankBean senderPhoneNumber, BankBean recievePhoneNumber);

	BankBean find(Long phoneNumber);

}
