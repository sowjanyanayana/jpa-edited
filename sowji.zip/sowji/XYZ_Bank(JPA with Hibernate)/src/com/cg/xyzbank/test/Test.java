package com.cg.xyzbank.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;

import com.cg.xyzbank.bean.AccountBean;
import com.cg.xyzbank.bean.CustomerBean;
import com.cg.xyzbank.service.BankServiceImpl;
import com.cg.xyzbank.service.IBankService;

public class Test {

	static IBankService service = null;

	@BeforeClass
	public static void createObject() {
		service = new BankServiceImpl();
	}

	@org.junit.Test(expected = Exception.class)
	public void createAccount() throws Exception {
		AccountBean accountBean = new AccountBean();
		accountBean.setBalance(2000);
		CustomerBean bean = new CustomerBean();
		bean.setFirstName("silpa");
		bean.setLastName("nayana");
		bean.setAge(21);
		bean.setAdhar(245781121382L);
		bean.setPhoneNo(9440640920L);
		bean.setAccountBean(accountBean);
		assertTrue(service.addCustomer(bean));
	}

	@org.junit.Test(expected = Exception.class)
	public void createAccountForFirstName() throws Exception {
		AccountBean accountBean = new AccountBean();
		accountBean.setBalance(2000);
		CustomerBean bean = new CustomerBean();
		bean.setFirstName("sil");
		bean.setLastName("nayana");
		bean.setAge(21);
		bean.setAdhar(245781121382L);
		bean.setPhoneNo(9440640920L);
		bean.setAccountBean(accountBean);
		assertFalse(service.addCustomer(bean));
		}

	@org.junit.Test(expected = Exception.class)
	public void createAccountForFirstNameForNull() throws Exception {
		AccountBean accountBean = new AccountBean();
		accountBean.setBalance(2000);
		CustomerBean bean = new CustomerBean();
		bean.setFirstName(null);
		bean.setLastName("nayana");
		bean.setAge(21);
		bean.setAdhar(245781121382L);
		bean.setPhoneNo(9440640920L);
		bean.setAccountBean(accountBean);
		assertFalse(service.addCustomer(bean));
		}

	@org.junit.Test(expected = Exception.class)
	public void createAccountForFirstNameForCharacters() throws Exception {
		AccountBean accountBean = new AccountBean();
		accountBean.setBalance(2000);
		CustomerBean bean = new CustomerBean();
		bean.setFirstName("si1234");
		bean.setLastName("nayana");
		bean.setAge(21);
		bean.setAdhar(245781121382L);
		bean.setPhoneNo(9440640920L);
		bean.setAccountBean(accountBean);
		assertFalse(service.addCustomer(bean));
		}
	

	@org.junit.Test(expected = Exception.class)
	public void createAccountForLastName() throws Exception {
		AccountBean accountBean = new AccountBean();
		accountBean.setBalance(2000);
		CustomerBean bean = new CustomerBean();
		bean.setFirstName("silpa");
		bean.setLastName("na");
		bean.setAge(21);
		bean.setAdhar(245781121382L);
		bean.setPhoneNo(9440640920L);
		bean.setAccountBean(accountBean);
		assertFalse(service.addCustomer(bean));	
		}

	@org.junit.Test(expected = Exception.class)
	public void createAccountForLastNameForNull() throws Exception {
		AccountBean accountBean = new AccountBean();
		accountBean.setBalance(2000);
		CustomerBean bean = new CustomerBean();
		bean.setFirstName("silpa");
		bean.setLastName(null);
		bean.setAge(21);
		bean.setAdhar(245781121382L);
		bean.setPhoneNo(9440640920L);
		bean.setAccountBean(accountBean);
		assertFalse(service.addCustomer(bean));
		}

	@org.junit.Test(expected = Exception.class)
	public void createAccountForLastNameForCharacters() throws Exception {
		AccountBean accountBean = new AccountBean();
		accountBean.setBalance(2000);
		CustomerBean bean = new CustomerBean();
		bean.setFirstName("silpa");
		bean.setLastName("1234");
		bean.setAge(21);
		bean.setAdhar(245781121382L);
		bean.setPhoneNo(9440640920L);
		bean.setAccountBean(accountBean);
		assertFalse(service.addCustomer(bean));
		}
	@org.junit.Test(expected = Exception.class)
	public void createAccountForAge() throws Exception {
		AccountBean accountBean = new AccountBean();
		accountBean.setBalance(2000);
		CustomerBean bean = new CustomerBean();
		bean.setFirstName("silpa");
		bean.setLastName("nayana");
		bean.setAge(2);
		bean.setAdhar(245781121382L);
		bean.setPhoneNo(9440640920L);
		bean.setAccountBean(accountBean);
		assertFalse(service.addCustomer(bean));	}
	@org.junit.Test(expected = Exception.class)
	public void createAccountForAdhar() throws Exception {
		AccountBean accountBean = new AccountBean();
		accountBean.setBalance(2000);
		CustomerBean bean = new CustomerBean();
		bean.setFirstName("silpa");
		bean.setLastName("nayana");
		bean.setAge(21);
		bean.setAdhar(24578112L);
		bean.setPhoneNo(9440640920L);
		bean.setAccountBean(accountBean);
		assertFalse(service.addCustomer(bean));
		}
	@org.junit.Test(expected = Exception.class)
	public void createAccountForPhoneNumber() throws Exception {
		AccountBean accountBean = new AccountBean();
		accountBean.setBalance(2000);
		CustomerBean bean = new CustomerBean();
		bean.setFirstName("silpa");
		bean.setLastName("nayana");
		bean.setAge(21);
		bean.setAdhar(245781121382L);
		bean.setPhoneNo(9440640920L);
		bean.setAccountBean(accountBean);
		assertFalse(service.addCustomer(bean));
		}

	@org.junit.Test(expected = Exception.class)
	public void createAccountForWrongPhoneNumber() throws Exception {
		AccountBean accountBean = new AccountBean();
		accountBean.setBalance(2000);
		CustomerBean bean = new CustomerBean();
		bean.setFirstName("silpa");
		bean.setLastName("nayana");
		bean.setAge(21);
		bean.setAdhar(245781121382L);
		bean.setPhoneNo(2598746325L);
		bean.setAccountBean(accountBean);
		assertFalse(service.addCustomer(bean));	
		}

	@org.junit.Test(expected = Exception.class)
	public void createAccountForPhoneNumberLength() throws Exception {
		AccountBean accountBean = new AccountBean();
		accountBean.setBalance(2000);
		CustomerBean bean = new CustomerBean();
		bean.setFirstName("silpa");
		bean.setLastName("nayana");
		bean.setAge(21);
		bean.setAdhar(245781121382L);
		bean.setPhoneNo(01120L);
		bean.setAccountBean(accountBean);
		assertFalse(service.addCustomer(bean));	
		}
	@org.junit.Test(expected = Exception.class)
	public void createAccountForIntialBalance() throws Exception {
		AccountBean accountBean = new AccountBean();
		accountBean.setBalance(-2000);
		CustomerBean bean = new CustomerBean();
		bean.setFirstName("silpa");
		bean.setLastName("nayana");
		bean.setAge(21);
		bean.setAdhar(245781121382L);
		bean.setPhoneNo(9440640920L);
		bean.setAccountBean(accountBean);
		assertFalse(service.addCustomer(bean));
		}
	@org.junit.Test
	public void Deposit() {
		AccountBean accountBean = new AccountBean();
		accountBean.setBalance(5000);
		accountBean.setPhoneNo(9032974524L);
		assertTrue(service.deposit(accountBean, 2000));
	}
	
	@org.junit.Test
	public void withDraw(){
		AccountBean accountBean = new AccountBean();
		accountBean.setBalance(5000);
		accountBean.setPhoneNo(9032974524L);
		assertTrue(service.withDraw(accountBean, 1000));
	}
	
	
	@org.junit.Test
	public void withDrawForWrongBalance(){
		AccountBean accountBean = new AccountBean();
		accountBean.setBalance(5000);
		assertFalse(service.withDraw(accountBean, 100000));
	}
	
	@org.junit.Test
	public void FundTransfer(){
		AccountBean accountBean1 = new AccountBean();
		accountBean1.setBalance(5000);
		accountBean1.setPhoneNo(9032974524L);
		AccountBean accountBean2 = new AccountBean();
		accountBean1.setBalance(5000);
		accountBean2.setPhoneNo(8978974524L);
		assertTrue(service.fundTransfer(1000,accountBean1, accountBean2));
	}
	
	
	@org.junit.Test
	public void FundTransferForWrongAmount(){
		AccountBean accountBean1 = new AccountBean();
		accountBean1.setBalance(5000);
		AccountBean accountBean2 = new AccountBean();
		accountBean1.setBalance(5000);
		assertFalse(service.fundTransfer(100000,accountBean1, accountBean2));
	}
	
	
	
}
