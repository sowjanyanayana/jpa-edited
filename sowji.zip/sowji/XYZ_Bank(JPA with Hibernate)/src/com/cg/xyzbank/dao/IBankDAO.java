package com.cg.xyzbank.dao;

import com.cg.xyzbank.bean.AccountBean;
import com.cg.xyzbank.bean.CustomerBean;

public interface IBankDAO {



	boolean deposit(AccountBean accountBean, double depositAmount);

	boolean withDraw(AccountBean accountBean, double withDrawAmount);

	boolean fundTransfer(double transferAmount, AccountBean senderPhoneNumber, AccountBean recievePhoneNumber);

	AccountBean find(Long phoneNumber);

	boolean addCustomer(CustomerBean customerBean);

}
