package com.cg.xyzbank.dao;

import javax.persistence.EntityManager;

import com.cg.xyzbank.bean.AccountBean;
import com.cg.xyzbank.bean.CustomerBean;

public class BankDAOImpl implements IBankDAO {

	
	@Override
	public boolean addCustomer(CustomerBean customerBean) {
		
		try {	
			EntityManager manager=JPAManager.createEntityManager();
	
			manager.getTransaction().begin();

			manager.persist(customerBean);
	
			manager.getTransaction().commit();
			JPAManager.close(manager);
		
			return true;
			
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		
	}
	
	
	@Override
	public boolean deposit(AccountBean accountBean, double depositAmount) {

		if(find(accountBean.getPhoneNo()) != null){
			
			accountBean.setBalance(accountBean.getBalance()+depositAmount);}
				
		return update(accountBean);
	}

	@Override
	public boolean withDraw(AccountBean accountBean, double withDrawAmount) {

		accountBean.setBalance(accountBean.getBalance()-withDrawAmount);

		return update(accountBean);
	}

	@Override
	public boolean fundTransfer(double transferAmount, AccountBean senderPhoneNumber, AccountBean recievePhoneNumber) {

			senderPhoneNumber.setBalance(senderPhoneNumber.getBalance()-transferAmount);
			recievePhoneNumber.setBalance(recievePhoneNumber.getBalance()+transferAmount);
			
		
		return update(senderPhoneNumber)&& update(recievePhoneNumber);
	}

	

	public boolean update(AccountBean accountBean) {

		try {
			EntityManager manager=JPAManager.createEntityManager();	
			manager.getTransaction().begin();
			manager.merge(accountBean);
			manager.getTransaction().commit();
			JPAManager.close(manager);
			return true;
		} catch (Exception e) {
			return false;
		}
		
	}

	@Override
	public AccountBean find(Long phoneNumber) {
		try {
			EntityManager manager=JPAManager.createEntityManager();	
			AccountBean accountBean1=manager.find(AccountBean.class,phoneNumber);

			JPAManager.close(manager);

			return accountBean1;
		} catch (Exception e) {
			return null;
			}
	}
	}
