package com.cg.xyzbank.service;

import com.cg.xyzbank.bean.AccountBean;
import com.cg.xyzbank.bean.CustomerBean;

public interface IBankService {

	boolean validations(CustomerBean customerBean) throws Exception;

	boolean deposit(AccountBean accountBean, double depositAmount);

	boolean withDraw(AccountBean accountBean, double withDrawAmount);

	AccountBean find(Long phoneNo);

	boolean fundTransfer(double transferAmount, AccountBean senderPhoneNumber, AccountBean recievePhoneNumber);

	boolean addCustomer(CustomerBean customerBean) throws Exception;

}
