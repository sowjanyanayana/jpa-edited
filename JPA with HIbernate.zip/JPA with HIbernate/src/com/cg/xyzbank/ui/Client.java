package com.cg.xyzbank.ui;

import java.util.Date;
import java.util.Scanner;

import com.cg.xyzbank.bean.BankBean;
import com.cg.xyzbank.bean.CustomerBean;
import com.cg.xyzbank.bean.TransactionBean;
import com.cg.xyzbank.dao.BankDAOImpl;
import com.cg.xyzbank.dao.IBankDAO;
import com.cg.xyzbank.service.BankServiceImpl;
import com.cg.xyzbank.service.IBankService;

public class Client {

	static Scanner scanner = new Scanner(System.in);
	static IBankService service = new BankServiceImpl();
	

	public static void main(String[] args) throws Exception {

		while (true) {

			System.out.println("*****XYZ BANK******");
			System.out.println("1.create Account\n2.Deposit\n3.WithDraw\n4.show Balance\n5.fund transfer\n6.printtransactions\n7.exit");
			System.out.print("enter your choice");
			int choice = scanner.nextInt();
			switch (choice) {
			case 1:
				addCustomer();
				break;
			case 2:
				Deposit();
				break;

			case 3:
				withDraw();
				break;

			case 4:
				showBalance();
				break;

			case 5:
				fundTransfer();
				break;

			case 6:
				transactions();
				break;

			case 7:
				System.exit(0);
				break;

			}
		}

	}

	public static void addCustomer() throws Exception {
		BankBean bankBean = new BankBean();
		CustomerBean customerBean1 = new CustomerBean();
		System.out.print("\t\tenter your first name\t\t:");
		String firstName = scanner.next();
		customerBean1.setFirstName(firstName);

		System.out.print("\t\tenter your last name\t\t:");
		String lastName = scanner.next();
		customerBean1.setLastName(lastName);

		System.out.print("\t\tenter your age\t\t\t:");
		int age = scanner.nextInt();
		customerBean1.setAge(age);

		System.out.print("\t\tenter your 12 digit adhar no.\t :");
		long adhar = scanner.nextLong();
		customerBean1.setAdhar(adhar);

		Date date = new Date();
		bankBean.setDate(date);

		System.out.print("\t\tenter your 10 digit phone number\t:");
		Long phoneNo = scanner.nextLong();
		bankBean.setPhoneNo(phoneNo);
		customerBean1.setPhoneNo(phoneNo);

		System.out.print("\t\tenter opening balance\t\t");
		Double balance = scanner.nextDouble();
		bankBean.setBalance(balance);

		
			if (service.validations(customerBean1,bankBean)) {
				
				bankBean.addTransactions(customerBean1);
				
				if (service.addCustomer(customerBean1,bankBean)) {

					System.out.println("\n\n\t\tcreated successfully\n\n\t\t");

				} else {
					System.out.println("\n\n\t\tAccount not created please try again\n\n\t\t");
				}
			}
		} 

	

	public static void Deposit() throws Exception {

		CustomerBean customerBean1 = new CustomerBean();
			System.out.println("enter phone number");
			Long phoneNo = scanner.nextLong();
			BankBean bankBean2 = service.find(phoneNo);
			if (bankBean2 != null) {
				System.out.println("enter the amount to deposit");
				double depositAmount = scanner.nextDouble();
				if(depositAmount>0){
				TransactionBean transactionBean = new TransactionBean();
				transactionBean.setDeposit(depositAmount);
				transactionBean.setTransactionType("deposit");
				transactionBean.setPhoneNo(phoneNo);
				customerBean1.addTransactions(transactionBean);

				if (service.deposit(bankBean2, depositAmount)) {
					System.out.println("amount deposited to your account");

				}} else {

					System.out.println("Amount not deposited please try again");
				}
			}else{
				System.out.println("sorry your account doesn't exist");
		}

	}

	public static void withDraw() throws Exception {
		
			CustomerBean customerBean1 = new CustomerBean();
		
			System.out.println("enter phone number");
			Long phoneNo = scanner.nextLong();
			BankBean bankBean = service.find(phoneNo);
			if (bankBean != null) {
				System.out.println("Enter the amount to withdraw");
				double withDrawAmount = scanner.nextDouble();

			if (withDrawAmount < bankBean.getBalance()) {
					TransactionBean transactionBean = new TransactionBean();
					transactionBean.setWithDraw(withDrawAmount);
					transactionBean.setTransactionType("withdraw");
					transactionBean.setPhoneNo(phoneNo);
					customerBean1.addTransactions(transactionBean);

				if (service.withDraw(bankBean, withDrawAmount))
				{
					System.out.println("\n\tamount withdrawn from your account");
				} 
				else 
				{
					System.out.println("\n\tFailed to withdraw please try Again");
				}
			}else{
				System.out.println("Insufficient Balance ");
			}
			}
			else {
			System.out.println("sorry your account doesn't exist");
		}
	}
	

	public static void showBalance() {
			
			System.out.println("enter phone number");
			Long phoneNo = scanner.nextLong();
			BankBean bankBean = service.find(phoneNo);
			if (bankBean != null) {
				System.out.println("your balance is=" + bankBean.getBalance());
			}
			else
			{
				System.out.println("sorry your account doesn't exist");
			}

		
	}

	public static void fundTransfer() {
		
			CustomerBean customerBean1 = new CustomerBean();
			System.out.println("enter your phone number");
			Long senderPhoneNumber = scanner.nextLong();
			BankBean bankBean1 = service.find(senderPhoneNumber);

			System.out.println("enter reciever phone number");
			Long recievePhoneNumber = scanner.nextLong();
			BankBean bankBean2 = service.find(recievePhoneNumber);

			if (bankBean1 != null && bankBean2 != null) {
				System.out.println("enter your transfer amount");
				double transferAmount = scanner.nextDouble();
				if (transferAmount < bankBean1.getBalance()) {
					TransactionBean transactionBean = new TransactionBean();
					transactionBean.setWithDraw(transferAmount);
					transactionBean.setTransactionType("withdraw(by fundtransfer)");
					transactionBean.setPhoneNo(senderPhoneNumber);
					customerBean1.addTransactions(transactionBean);

					TransactionBean transactionBean1 = new TransactionBean();
					transactionBean1.setDeposit(transferAmount);
					transactionBean1.setTransactionType("deposit(by fundtransfer)");
					transactionBean1.setPhoneNo(recievePhoneNumber);
					customerBean1.addTransactions(transactionBean1);

					if (service.fundTransfer(transferAmount, bankBean1,bankBean2)) {
						System.out.println("transfered succcessfully");

					}
					}else {
						System.out.println("Insufficient Balance");
					}
					}
			else
					{
						System.out.println("please check your accounts");
					}
			
			

	}

	public static void transactions() {

		CustomerBean customerBean1 = new CustomerBean();
		System.out.println("enter your phone num");
		Long senderPhoneNumber = scanner.nextLong();
		BankBean bankBean1 = service.find(senderPhoneNumber);
		if (bankBean1 != null) {

			System.out.println(customerBean1.getTransactions());
		}

	}

}
